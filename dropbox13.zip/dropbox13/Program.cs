﻿// Lenz Vital
// CISS 201 DEA
// Assignment 13 Programming Challenge 6.2
// 02/12/2024

using System;
using System.Collections.Generic;
using EmployeeApp.Models; // Import Employee namespace

class Program
{
    static void Main()
    {
        // Create a list of employees with different types
        List<Employee> employees = new List<Employee>
        {
            new FulltimeEmployee(101, "James Harden", 52000), // Full-time Employee
            new FulltimeEmployee(102, "Kobe Bryant", 75000), // Full-time Employee
            new ParttimeEmployee(103, "Ja Morant", 20, 25), // Part-time Employee
            new ParttimeEmployee(104, "Lebron James", 18, 30) // Part-time Employee
        };

        Console.WriteLine("Employee Payment Details:\n"); // Print Header

        // Loop through each employee and print details
        foreach (var emp in employees)
        {
            Console.WriteLine(emp); // Calls the overridden ToString() method
        }
    }
}


