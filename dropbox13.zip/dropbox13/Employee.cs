﻿namespace EmployeeApp.Models // Define namespace
{
    public abstract class Employee // Abstract base class
    {
        public int EmployeeID { get; set; } // Property to store Employee ID
        public string EmployeeName { get; set; } // Property to store Employee Name

        // Constructor to initialize Employee ID and Name
        public Employee(int employeeID, string employeeName)
        {
            EmployeeID = employeeID;
            EmployeeName = employeeName;
        }

        // Abstract method that must be implemented by derived classes
        public abstract double GetWeeklyPaid();

        // Override ToString method to display Employee ID and Name
        public override string ToString()
        {
            return $"Employee ID: {EmployeeID}, Name: {EmployeeName}";
        }
    }
}

