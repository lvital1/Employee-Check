﻿namespace EmployeeApp.Models
{
    public class FulltimeEmployee : Employee // Inherits from Employee
    {
        public double Salary { get; set; } // Property for annual salary

        // Constructor initializes Employee ID, Name, and Salary
        public FulltimeEmployee(int employeeID, string employeeName, double salary)
            : base(employeeID, employeeName) // Call base constructor
        {
            Salary = salary;
        }

        // Override GetWeeklyPaid to calculate weekly salary
        public override double GetWeeklyPaid()
        {
            return Salary / 52; // Annual salary divided by 52 weeks
        }

        // Override ToString to include Weekly Pay
        public override string ToString()
        {
            return base.ToString() + $", Weekly Pay: {GetWeeklyPaid():C}";
        }
    }
}
