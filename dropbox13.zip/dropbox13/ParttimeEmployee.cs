﻿namespace EmployeeApp.Models
{
    public class ParttimeEmployee : Employee // Inherits from Employee
    {
        public double HourlyRate { get; set; } // Property for hourly rate
        public double HoursWorked { get; set; } // Property for hours worked in a week

        // Constructor initializes Employee ID, Name, Hourly Rate, and Hours Worked
        public ParttimeEmployee(int employeeID, string employeeName, double hourlyRate, double hoursWorked)
            : base(employeeID, employeeName) // Call base constructor
        {
            HourlyRate = hourlyRate;
            HoursWorked = hoursWorked;
        }

        // Override GetWeeklyPaid to calculate weekly earnings
        public override double GetWeeklyPaid()
        {
            return HourlyRate * HoursWorked; // Multiply hours worked by hourly rate
        }

        // Override ToString to include Weekly Pay
        public override string ToString()
        {
            return base.ToString() + $", Weekly Pay: {GetWeeklyPaid():C}";
        }
    }
}
